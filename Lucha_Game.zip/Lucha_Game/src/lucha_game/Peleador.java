/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lucha_game;

/**
 *
 * @author ASUS
 */
public class Peleador {
    
    protected String nombre;
    protected int vida;
    protected int ataque;
    protected int defensa;
    protected int victoria;

    public Peleador(String nombre, int vida, int ataque, int defensa, int victoria) {
        this.nombre = nombre;
        this.vida = vida;
        this.ataque = ataque;
        this.defensa = defensa;
        this.victoria = victoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getDefensa() {
        return defensa;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }

    public int getVictoria() {
        return victoria;
    }

    public void setVictoria(int victoria) {
        this.victoria = victoria;
    }
    
    public void mostrar (){
        System.out.println(" ");
        System.out.println("Nombre "+ this.getNombre() +", Ataque " + this.getAtaque()+", Vida "+this.getVida()
                +", Defensa "+this.getDefensa()+ ", Victorias "+this.getVictoria());   
    }
    public void atacar(Espadachin enemigo){
        
        int dado10=0, dano=0;  
        int dado5=0;
        
        dado10=(int) (Math.random()*10)+1; 
        dado5=(int) (Math.random()*5);
        
        this.setAtaque(dado10);
        enemigo.setDefensa(dado5);
        
        System.out.println("Ataque: " +this.getAtaque()+ " Nombre: "+this.getNombre());
        System.out.println("Defensa: "+enemigo.getDefensa()+ " Nombre: "+ enemigo.getNombre());
        
        dano=this.getAtaque()-enemigo.getDefensa();
        
        if(this.getAtaque()>enemigo.getDefensa()){
            enemigo.mostrar();
            enemigo.setVida(enemigo.getVida()-dano);
            enemigo.mostrar();
            
        }
        if(dano>0){
            System.out.println("Golpe exitoso! "+ enemigo.getNombre()+" pierde "+dano+ " de vida");
            System.out.println("");
        }else{
           System.out.println("Ataque bloqueado " +enemigo.getNombre()+" no recibe golpe " + "sigue con "+enemigo.getVida()+" de vida");
           System.out.println("");
        }
       
        if (this.getAtaque()==10 && enemigo.getDefensa()==0){
            enemigo.setVida(0);
            System.out.println("FATLITYYYYYYY...! ha matado a "+ enemigo.getNombre()+" de un golpe");
            System.out.println("");
        }
    }
    /*public void hechizar (Magibow Espadachin){
        
        int dado10=0, dano=0;  
        int dado5=0;
        
        dado10=(int) (Math.random()*10)+1; 
        dado5=(int) (Math.random()*5);
        
        this.setAtaque(dado10);
        Espadachin.setDefensa(dado5);
        
        System.out.println("Ataque: " +this.getAtaque()+ " Nombre: "+this.getNombre());
        System.out.println("Defensa: "+Espadachin.getDefensa()+ " Nombre: "+ Espadachin.getNombre());
        
        dano=this.getAtaque()-Espadachin.getDefensa();
        
        if(this.getAtaque()>Espadachin.getDefensa()){
            Espadachin.mostrar();
            Espadachin.setVida(Espadachin.getVida()-dano);
            Espadachin.mostrar();
            
        }
        if(dano>0){
            System.out.println("Golpe exitoso! "+ Espadachin.getNombre()+" pierde "+dano+ " de vida");
            System.out.println("");
        }else{
           System.out.println("Ataque bloqueado " +Espadachin.getNombre()+" no recibe golpe " + "sigue con "+Espadachin.getVida()+" de vida");
           System.out.println("");
        }
       
        if (this.getAtaque()==10 && Espadachin.getDefensa()==0){
            Espadachin.setVida(0);
            System.out.println("FATLITYYYYYYY...! ha matado a "+ Espadachin.getNombre()+" de un golpe");
            System.out.println("");
        }
    }*/
}
