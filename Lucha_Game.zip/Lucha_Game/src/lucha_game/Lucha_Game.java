/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lucha_game;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Lucha_Game {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { //(String nombre, int vida, int ataque, int defensa, int victoria)
        Scanner scanner = new Scanner(System.in);
        
        Espadachin espadachin = new Espadachin ("Shaoyan", 100, 15, 5, 0);
        Magibow magibow = new Magibow ("Lunarys", 100, 12, 8, 0);
        espadachin.mostrar();
        magibow.mostrar();
        

         // Variable para alternar turnos (true = Espadachín, false = Magibow)
        boolean turnoEspadachin = true;

        // Bucle de combate
        while (espadachin.vida > 0 && magibow.vida > 0) {
            if (turnoEspadachin) {
                // Turno del Espadachín
                System.out.println("\nTurno de " + espadachin.nombre + ":");
                System.out.println("1. Atacar");
                System.out.println("2. Bloquear");
                System.out.println("3. Usar hacha");
                System.out.println("4. Aumentar fuerza");
                int opcion = scanner.nextInt();

                switch (opcion) {
                    case 1 -> espadachin.atacar(magibow);
                    case 2 -> espadachin.bloqueo();
                    case 3 -> espadachin.usar_acha(magibow);
                    case 4 -> espadachin.aumentar_fuerza();
                    default -> System.out.println("Opción inválida.");
                }
            } else {
                // Turno de Magibow
                System.out.println("\nTurno de " + magibow.nombre + ":");
                System.out.println("1. Atacar");
                System.out.println("2. Hechizar");
                System.out.println("3. Flechar");
                System.out.println("4. Usar arco");
                int opcion = scanner.nextInt();

                switch (opcion) {
                    case 1 -> magibow.atacar(espadachin);
                    case 2 -> magibow.hechizar(espadachin);
                    case 3 -> magibow.flechar(espadachin);
                    case 4 -> magibow.usar_arco(espadachin);
                    default -> System.out.println("Opción inválida.");
                }
            }

            // Mostrar estado después del turno
            espadachin.mostrar();
            magibow.mostrar();

            // Comprobar si alguien perdió
            if (magibow.vida <= 0) {
                System.out.println("¡" + espadachin.nombre + " ha ganado!");
                break;
            }
            if (espadachin.vida <= 0) {
                System.out.println("¡" + magibow.nombre + " ha ganado!");
                break;
            }

            // Cambiar el turno
            turnoEspadachin = !turnoEspadachin;
        }

        scanner.close();
        /*while(e1.getVida()>0 && m1.getVida()>0){
            e1.atacar(m1);
             if (m1.getVida() > 0) { 
                e2.atacar(e1);
            }
        }
        if(e1.getVida()>e2.getVida()){
            e1.setVictoria(e1.getVictoria()+1);
        System.out.println("Ganadoooor...! " +e1.getNombre());
    }else{
            e2.setVictoria(e2.getVictoria()+1);
        System.out.println("Ganadoooor...! " +e2.getNombre());
        }*/
    }  
}
